import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react(), tailwindcss()],
  // Update this base path with your GitHub repository name
  // Format: '/repository-name/'
  // Example: If your repo is 'benoni-boksburg-realestate', use '/benoni-boksburg-realestate/'
  base: '/',
  build: {
    outDir: 'dist',
    assetsDir: 'assets',
    sourcemap: false,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'ui-components': [
            './components/ui/button.tsx',
            './components/ui/card.tsx',
            './components/ui/dialog.tsx',
            './components/ui/input.tsx',
          ],
        },
      },
    },
  },
  server: {
    port: 3000,
    open: true,
  },
});
