import { lazy, Suspense } from 'react';
import { BuyerContactForm } from './components/BuyerContactForm';
import { AffordabilityCalculator } from './components/AffordabilityCalculator';
import { BuyingProcess } from './components/BuyingProcess';
import { SellingSection } from './components/SellingSection';
import { ImageWithFallback } from './components/figma/ImageWithFallback';
import { Toaster } from './components/ui/sonner';
import { Home, Phone, MapPin, Loader2 } from 'lucide-react';
import { Button } from './components/ui/button';

// Lazy load heavy components
const SuburbComparison = lazy(() => import('./components/SuburbComparison').then(m => ({ default: m.SuburbComparison })));
const InteractiveMap = lazy(() => import('./components/InteractiveMap').then(m => ({ default: m.InteractiveMap })));
const MarketTrends = lazy(() => import('./components/MarketTrends').then(m => ({ default: m.MarketTrends })));
const BuyingProgressTracker = lazy(() => import('./components/BuyingProgressTracker').then(m => ({ default: m.BuyingProgressTracker })));
const SellingProgressTracker = lazy(() => import('./components/SellingProgressTracker').then(m => ({ default: m.SellingProgressTracker })));
const ServiceRating = lazy(() => import('./components/ServiceRating').then(m => ({ default: m.ServiceRating })));
const PropertyListings = lazy(() => import('./components/PropertyListings').then(m => ({ default: m.PropertyListings })));

// Loading component
function SectionLoader() {
  return (
    <div className="flex items-center justify-center py-20">
      <Loader2 className="h-8 w-8 animate-spin text-white" />
    </div>
  );
}

export default function App() {
  const handleWhatsAppContact = () => {
    const whatsappNumber = '27823146558';
    const message = encodeURIComponent('Hi! I\'d like to inquire about buying a property in Benoni/Boksburg.');
    window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
  };

  return (
    <div className="min-h-screen bg-background">
      <Toaster />
      
      {/* Hero Section */}
      <section className="relative bg-grey text-white overflow-hidden border-b border-border">
        <div className="absolute inset-0 opacity-10">
          <ImageWithFallback
            src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBob3VzZSUyMGV4dGVyaW9yfGVufDF8fHx8MTc1OTc2MDk5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
            alt="Modern house"
            className="w-full h-full object-cover"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-grey/95 via-grey/90 to-black"></div>
        <div className="relative max-w-7xl mx-auto px-4 py-20 md:py-32">
          <div className="max-w-3xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-3 bg-white/10 rounded-lg backdrop-blur-sm border border-white/20">
                <Home className="h-8 w-8 text-white" />
              </div>
              <span className="text-xl tracking-wide text-white">Your Trusted Real Estate Agent</span>
            </div>
            <h1 className="mb-6 leading-tight text-white">Find Your Dream Home in Benoni & Boksburg</h1>
            <p className="text-lg text-white/90 mb-10 leading-relaxed">
              I specialize in helping buyers find the perfect property in Benoni and Boksburg. 
              From your first viewing to receiving your keys, I'll guide you through every step 
              of the home buying journey with expertise and dedication.
            </p>
            <div className="flex flex-wrap gap-4">
              <Button 
                size="lg"
                onClick={handleWhatsAppContact}
                className="shadow-lg hover:shadow-xl transition-shadow bg-white text-black hover:bg-white/90"
              >
                <Phone className="mr-2 h-5 w-5" />
                Contact Me on WhatsApp
              </Button>
              <Button 
                size="lg" 
                variant="outline"
                className="bg-transparent border-2 border-white text-white hover:bg-white/10 transition-all shadow-lg"
                onClick={() => document.getElementById('contact-form')?.scrollIntoView({ behavior: 'smooth' })}
              >
                Get Started
              </Button>
            </div>
            
            {/* Quick Contact Info */}
            <div className="mt-12 pt-8 border-t border-white/20 flex flex-wrap gap-8">
              <div className="flex items-center gap-3 text-white">
                <div className="p-2 bg-white/10 rounded-full border border-white/20">
                  <Phone className="h-4 w-4" />
                </div>
                <span className="text-white">082 314 6558</span>
              </div>
              <div className="flex items-center gap-3 text-white">
                <div className="p-2 bg-white/10 rounded-full border border-white/20">
                  <MapPin className="h-4 w-4" />
                </div>
                <span className="text-white">Benoni & Boksburg</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Suburb Comparison Section */}
      <section className="py-20 px-4 bg-background">
        <Suspense fallback={<SectionLoader />}>
          <SuburbComparison />
        </Suspense>
      </section>

      {/* Interactive Map Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <InteractiveMap />
        </Suspense>
      </section>

      {/* Market Trends Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <MarketTrends />
        </Suspense>
      </section>

      {/* Contact Form Section */}
      <section id="contact-form" className="py-20 px-4 bg-background border-t border-border">
        <BuyerContactForm />
      </section>

      {/* Property Listings Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <PropertyListings />
        </Suspense>
      </section>

      {/* Affordability Calculator Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <AffordabilityCalculator />
      </section>

      {/* Buying Progress Tracker */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <BuyingProgressTracker />
        </Suspense>
      </section>

      {/* Buying Process Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <BuyingProcess />
      </section>

      {/* Selling Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <SellingSection />
      </section>

      {/* Selling Progress Tracker */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <SellingProgressTracker />
        </Suspense>
      </section>

      {/* Service Rating Section */}
      <section className="py-20 px-4 bg-background border-t border-border">
        <Suspense fallback={<SectionLoader />}>
          <ServiceRating />
        </Suspense>
      </section>

      {/* Footer */}
      <footer className="bg-grey text-white py-16 px-4 mt-8 border-t border-border">
        <div className="max-w-7xl mx-auto text-center space-y-6">
          <div className="flex items-center justify-center gap-3">
            <div className="p-3 bg-white/10 rounded-lg border border-white/20">
              <Home className="h-6 w-6 text-white" />
            </div>
            <span className="text-xl tracking-wide text-white">Your Real Estate Partner</span>
          </div>
          <p className="text-white/80 max-w-md mx-auto">
            Serving Benoni, Boksburg, and surrounding areas with dedication and expertise
          </p>
          <div className="flex justify-center gap-6">
            <button 
              onClick={handleWhatsAppContact}
              className="hover:underline flex items-center gap-2 bg-white/10 px-6 py-3 rounded-lg hover:bg-white/20 transition-all border border-white/20 text-white"
            >
              <Phone className="h-4 w-4" />
              <span>082 314 6558</span>
            </button>
          </div>
          <div className="pt-8 border-t border-white/20">
            <p className="text-sm text-white/60">
              © {new Date().getFullYear()} Real Estate Benoni & Boksburg - All rights reserved
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
