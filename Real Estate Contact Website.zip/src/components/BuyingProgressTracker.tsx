import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Checkbox } from './ui/checkbox';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { CheckCircle2, Circle, Clock, AlertCircle } from 'lucide-react';

interface Step {
  id: string;
  title: string;
  description: string;
  estimatedDays: string;
  tasks: {
    id: string;
    title: string;
    completed: boolean;
  }[];
}

export function BuyingProgressTracker() {
  const [steps, setSteps] = useState<Step[]>([
    {
      id: 'consultation',
      title: 'Initial Consultation',
      description: 'Understanding your needs and budget',
      estimatedDays: '1-2 days',
      tasks: [
        { id: 'meet', title: 'Meet with agent', completed: false },
        { id: 'budget', title: 'Discuss budget & requirements', completed: false },
        { id: 'preapproval', title: 'Get bond pre-approval', completed: false }
      ]
    },
    {
      id: 'search',
      title: 'Property Search',
      description: 'Finding your perfect home',
      estimatedDays: '2-4 weeks',
      tasks: [
        { id: 'viewings', title: 'Schedule property viewings', completed: false },
        { id: 'shortlist', title: 'Create shortlist', completed: false },
        { id: 'decision', title: 'Make final decision', completed: false }
      ]
    },
    {
      id: 'offer',
      title: 'Making an Offer',
      description: 'Submitting your offer to purchase',
      estimatedDays: '3-7 days',
      tasks: [
        { id: 'prepare', title: 'Prepare offer to purchase', completed: false },
        { id: 'negotiate', title: 'Negotiate terms', completed: false },
        { id: 'accept', title: 'Offer accepted', completed: false }
      ]
    },
    {
      id: 'bond',
      title: 'Bond Application',
      description: 'Securing your home loan',
      estimatedDays: '2-4 weeks',
      tasks: [
        { id: 'submit', title: 'Submit bond application', completed: false },
        { id: 'docs', title: 'Provide required documents', completed: false },
        { id: 'approval', title: 'Bond approval received', completed: false }
      ]
    },
    {
      id: 'inspection',
      title: 'Property Inspection',
      description: 'Ensuring everything is in order',
      estimatedDays: '1-2 weeks',
      tasks: [
        { id: 'electrical', title: 'Electrical compliance certificate', completed: false },
        { id: 'plumbing', title: 'Plumbing inspection', completed: false },
        { id: 'general', title: 'General property inspection', completed: false }
      ]
    },
    {
      id: 'transfer',
      title: 'Transfer & Registration',
      description: 'Legal transfer process',
      estimatedDays: '8-12 weeks',
      tasks: [
        { id: 'attorney', title: 'Transfer attorney appointed', completed: false },
        { id: 'deeds', title: 'Deeds office registration', completed: false },
        { id: 'keys', title: 'Receive keys!', completed: false }
      ]
    }
  ]);

  const toggleTask = (stepId: string, taskId: string) => {
    setSteps(steps.map(step => {
      if (step.id === stepId) {
        return {
          ...step,
          tasks: step.tasks.map(task =>
            task.id === taskId ? { ...task, completed: !task.completed } : task
          )
        };
      }
      return step;
    }));
  };

  const totalTasks = steps.reduce((acc, step) => acc + step.tasks.length, 0);
  const completedTasks = steps.reduce((acc, step) => 
    acc + step.tasks.filter(task => task.completed).length, 0
  );
  const progress = (completedTasks / totalTasks) * 100;

  const getStepStatus = (step: Step) => {
    const completed = step.tasks.filter(t => t.completed).length;
    const total = step.tasks.length;
    if (completed === total) return 'completed';
    if (completed > 0) return 'in-progress';
    return 'pending';
  };

  return (
    <div className="w-full max-w-6xl mx-auto space-y-8">
      <div className="text-center space-y-3">
        <div className="flex items-center justify-center gap-3 mb-4">
          <div className="p-3 bg-card rounded-lg">
            <CheckCircle2 className="h-8 w-8 text-white" />
          </div>
        </div>
        <h2 className="text-white">Your Buying Journey Progress</h2>
        <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
          Track your progress and stay informed every step of the way
        </p>
      </div>

      {/* Overall Progress */}
      <Card className="bg-card border-border">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white">Overall Progress</CardTitle>
              <CardDescription className="text-muted-foreground">
                {completedTasks} of {totalTasks} tasks completed
              </CardDescription>
            </div>
            <Badge variant="secondary" className="bg-secondary text-white text-lg px-4 py-2">
              {Math.round(progress)}%
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <Progress value={progress} className="h-3" />
        </CardContent>
      </Card>

      {/* Steps */}
      <div className="space-y-4">
        {steps.map((step, index) => {
          const status = getStepStatus(step);
          const stepCompleted = step.tasks.filter(t => t.completed).length;
          const stepTotal = step.tasks.length;
          
          return (
            <Card key={step.id} className="bg-card border-border">
              <CardHeader>
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    {status === 'completed' ? (
                      <div className="p-2 bg-green-900/30 rounded-full border-2 border-green-400">
                        <CheckCircle2 className="h-6 w-6 text-green-400" />
                      </div>
                    ) : status === 'in-progress' ? (
                      <div className="p-2 bg-blue-900/30 rounded-full border-2 border-blue-400">
                        <Clock className="h-6 w-6 text-blue-400" />
                      </div>
                    ) : (
                      <div className="p-2 bg-background rounded-full border-2 border-border">
                        <Circle className="h-6 w-6 text-muted-foreground" />
                      </div>
                    )}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <CardTitle className="text-white mb-1">
                          Step {index + 1}: {step.title}
                        </CardTitle>
                        <CardDescription className="text-muted-foreground">
                          {step.description}
                        </CardDescription>
                      </div>
                      <Badge variant="outline" className="border-white/20 text-white">
                        {step.estimatedDays}
                      </Badge>
                    </div>

                    <div className="mt-4 space-y-3">
                      {step.tasks.map((task) => (
                        <div 
                          key={task.id}
                          className="flex items-center gap-3 p-3 bg-background rounded-lg border border-border hover:border-white/30 transition-colors"
                        >
                          <Checkbox
                            id={`${step.id}-${task.id}`}
                            checked={task.completed}
                            onCheckedChange={() => toggleTask(step.id, task.id)}
                            className="border-white/30 data-[state=checked]:bg-white data-[state=checked]:text-black"
                          />
                          <label
                            htmlFor={`${step.id}-${task.id}`}
                            className={`flex-1 cursor-pointer ${
                              task.completed ? 'line-through text-muted-foreground' : 'text-white'
                            }`}
                          >
                            {task.title}
                          </label>
                          {task.completed && (
                            <CheckCircle2 className="h-4 w-4 text-green-400" />
                          )}
                        </div>
                      ))}
                    </div>

                    <div className="mt-3 flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">
                        {stepCompleted} of {stepTotal} tasks completed
                      </span>
                      <Progress 
                        value={(stepCompleted / stepTotal) * 100} 
                        className="w-32 h-2"
                      />
                    </div>
                  </div>
                </div>
              </CardHeader>
            </Card>
          );
        })}
      </div>

      {/* Help Section */}
      <Card className="bg-card border-border border-white/30">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <AlertCircle className="h-5 w-5 text-white flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="text-white mb-2">Need help with any step?</p>
              <p className="text-muted-foreground text-sm mb-4">
                I'm here to guide you through every stage of your property buying journey. 
                Don't hesitate to reach out if you have questions or need assistance.
              </p>
              <Button 
                onClick={() => {
                  const whatsappNumber = '27823146558';
                  const message = encodeURIComponent('Hi! I need help with my property buying process.');
                  window.open(`https://wa.me/${whatsappNumber}?text=${message}`, '_blank');
                }}
                className="bg-primary hover:bg-primary/80 text-white"
              >
                Contact Me on WhatsApp
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
