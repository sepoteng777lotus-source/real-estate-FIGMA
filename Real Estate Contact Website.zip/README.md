
  # Real Estate Contact Website

  This is a code bundle for Real Estate Contact Website. The original project is available at https://www.figma.com/design/zfjPdY4oin0WvwWMuBz18I/Real-Estate-Contact-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  